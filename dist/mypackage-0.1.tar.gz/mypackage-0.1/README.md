# mypackage 
This librery was created as an example of how to create a package in Python. It is not intended to be used in production.
